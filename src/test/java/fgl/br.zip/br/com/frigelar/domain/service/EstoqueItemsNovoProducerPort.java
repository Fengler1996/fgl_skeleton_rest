package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.EstoqueItemsNovo;
import io.smallrye.mutiny.Uni;

public interface EstoqueItemsNovoProducerPort {
    Uni<EstoqueItemsNovo> sendCreate(EstoqueItemsNovo estoqueItemsNovo);
    Uni<EstoqueItemsNovo> sendUpdate(EstoqueItemsNovo estoqueItemsNovo);
}
