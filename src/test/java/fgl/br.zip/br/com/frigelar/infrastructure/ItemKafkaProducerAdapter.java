package br.com.frigelar.infrastructure;

import br.com.frigelar.domain.model.Item;
import br.com.frigelar.domain.service.ItemProducerPort;
import br.com.frigelar.infrastructure.kafka.dto.ItemOutTopicKafkaDTO;
import br.com.frigelar.infrastructure.kafka.dto.OutTopicKafkaDTO;
import io.smallrye.mutiny.Uni;
import io.smallrye.reactive.messaging.MutinyEmitter;
import io.smallrye.reactive.messaging.kafka.api.OutgoingKafkaRecordMetadata;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.reactive.messaging.Channel;
import org.eclipse.microprofile.reactive.messaging.Message;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@RequiredArgsConstructor
public class ItemKafkaProducerAdapter implements ItemProducerPort {

    @Channel("petra2-product-item-create-out")
    MutinyEmitter<ItemOutTopicKafkaDTO> messageRequestEmitterCreate;

    @Channel("petra2-product-item-update-out")
    MutinyEmitter<OutTopicKafkaDTO> messageRequestEmitterUpdate;

    @Override
    public Uni<Item> sendCreate(Item item) {
        messageRequestEmitterCreate.send(Message.of(ItemOutTopicKafkaDTO.builder().id(item.getId()).idKitAr(item.getKitId()).build())
                .addMetadata(OutgoingKafkaRecordMetadata.<String>builder()
                        .withKey(item.getId())
                        .build()));
        return Uni.createFrom().item(item);
    }

    @Override
    public Uni<Item> sendUpdate(Item item) {
        messageRequestEmitterUpdate.send(Message.of(OutTopicKafkaDTO.builder().id(item.getId()).build())
                .addMetadata(OutgoingKafkaRecordMetadata.<String>builder()
                        .withKey(item.getId())
                        .build()));
        return Uni.createFrom().item(item);
    }
}
