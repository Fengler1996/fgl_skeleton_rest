package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.EstoqueItemsNovo;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@RequiredArgsConstructor
public class EstoqueItemsNovoServiceImpl implements EstoqueItemsNovoService {

    private final EstoqueItemsNovoPort estoqueItemsNovoPort;
    private final EstoqueItemsNovoProducerPort estoqueItemsNovoProducerPort;

    @Override
    public Uni<EstoqueItemsNovo> save(EstoqueItemsNovo estoqueItemsNovo) {
        return estoqueItemsNovoPort.save(estoqueItemsNovo).flatMap(e -> estoqueItemsNovoProducerPort.sendCreate(estoqueItemsNovo));
    }

    @Override
    public Uni<EstoqueItemsNovo> update(EstoqueItemsNovo estoqueItemsNovo) {
        return estoqueItemsNovoPort.update(estoqueItemsNovo).flatMap(e -> estoqueItemsNovoProducerPort.sendUpdate(estoqueItemsNovo));
    }

    @Override
    public Uni<EstoqueItemsNovo> byID(String id) {
        return estoqueItemsNovoPort.byId(id);
    }

}
