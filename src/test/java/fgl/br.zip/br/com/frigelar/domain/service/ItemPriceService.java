package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.ItemPrice;
import io.smallrye.mutiny.Uni;

public interface ItemPriceService {

    Uni<ItemPrice> save(ItemPrice itemPrice);

    Uni<ItemPrice> update(ItemPrice itemPrice);

    Uni<ItemPrice> byID(String id);
}
