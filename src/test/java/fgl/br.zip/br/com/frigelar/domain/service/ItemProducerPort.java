package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.Item;
import io.smallrye.mutiny.Uni;

public interface ItemProducerPort {
    Uni<Item> sendCreate(Item item);
    Uni<Item> sendUpdate(Item item);
}
