package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.KitAr;
import io.smallrye.mutiny.Uni;

public interface KitArProducerPort {
    Uni<KitAr> sendCreate(KitAr kitAr);
    Uni<KitAr> sendUpdate(KitAr kitAr);
}
