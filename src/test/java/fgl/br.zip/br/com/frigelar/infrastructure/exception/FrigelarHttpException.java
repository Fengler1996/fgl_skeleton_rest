package br.com.frigelar.infrastructure.exception;


import java.io.Serial;

public class FrigelarHttpException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = 1L;
    private final int code;

    public FrigelarHttpException(String message, Throwable cause) {
        this(500, message, cause);
    }

    public FrigelarHttpException(int code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public FrigelarHttpException(String message) {
        this(500, message);
    }

    public FrigelarHttpException(int code, String message) {
        super(message);
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
