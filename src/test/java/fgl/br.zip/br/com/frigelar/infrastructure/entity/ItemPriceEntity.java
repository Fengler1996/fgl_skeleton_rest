package br.com.frigelar.infrastructure.entity;

import io.quarkus.mongodb.panache.common.MongoEntity;
import io.quarkus.mongodb.panache.reactive.ReactivePanacheMongoEntity;
import lombok.Getter;
import lombok.Setter;

@MongoEntity(collection = "mdm_ms_item_price")
@Getter
@Setter
public class ItemPriceEntity extends ReactivePanacheMongoEntity {

    private String id;
    private String description;
    private String fiscalEstablishmentId;
    private Double fromPrice;
    private Double price;
}
