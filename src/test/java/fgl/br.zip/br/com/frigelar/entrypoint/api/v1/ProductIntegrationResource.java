package br.com.frigelar.entrypoint.api.v1;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Path;

import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;

@ApplicationScoped
@Path("/v1/")
@SecurityRequirement(name = "Keycloak")
public class ProductIntegrationResource {
	
	
	
}
