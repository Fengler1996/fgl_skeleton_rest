package br.com.frigelar.entrypoint.api.v1.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.util.List;

@Schema(name = "ItemPriceResponseDTO", description = "Objeto de response")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ItemPriceResponseDTO {

    @JsonProperty("ItemPrice")
    private List<ItemPriceDTO> itemPriceDTOList;

}
