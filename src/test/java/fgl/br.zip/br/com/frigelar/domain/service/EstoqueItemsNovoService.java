package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.EstoqueItemsNovo;
import io.smallrye.mutiny.Uni;

public interface EstoqueItemsNovoService {

    Uni<EstoqueItemsNovo> save(EstoqueItemsNovo item);

    Uni<EstoqueItemsNovo> update(EstoqueItemsNovo item);

    Uni<EstoqueItemsNovo> byID(String id);
}
