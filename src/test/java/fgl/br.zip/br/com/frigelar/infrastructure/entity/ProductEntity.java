package br.com.frigelar.infrastructure.entity;

import java.math.BigDecimal;

import io.quarkus.mongodb.panache.common.MongoEntity;
import io.quarkus.mongodb.panache.reactive.ReactivePanacheMongoEntity;
import lombok.Getter;
import lombok.Setter;

@MongoEntity(collection = "mdm_ms_product")
@Getter
@Setter
public class ProductEntity extends ReactivePanacheMongoEntity {
	
	private String name;
	private Boolean lockedShop;
	private Boolean lockedPartner;
	private Boolean finalLocked;
	private Boolean manufacturerLogo;
	private Boolean homeShop;
	private Boolean finalHome;
	private Boolean homePartner;
	private Boolean orderShop;
	private Boolean finalOrder;
	private Boolean orderPartner;
	private String url;
	private Integer categoryIdSite;
	private BigDecimal maximumSaleQuantity;
	private Boolean lockedInstaller;
	private Boolean homeInstaller;
	private Boolean orderInstaller;
	private Integer installments;
	private String primaryVendorId;
	private BigDecimal netWeight;
	private BigDecimal grossDepth;
	private BigDecimal grossWidth;
	private BigDecimal grossHeight;
	private BigDecimal containerWeight;
	private String taxFiscalClassificationBR;
	private Boolean taxationOriginBr;
	private String fglSuperFamily;
	private String ecManufacture;
	private String brand;
	private String ecVoltage;
	private String fglProductLine;
	private String fglFamilyItem;
	private String fglReference;
	private String fglReferenceFor;
	private Integer fglWarrantyTime;
	private String fglEcDescriptive;
	private String universalPhoto;
	private String fglClone;
	private String unitId;
	
}
