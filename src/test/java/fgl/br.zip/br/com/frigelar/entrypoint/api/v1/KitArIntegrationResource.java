package br.com.frigelar.entrypoint.api.v1;

import br.com.frigelar.domain.service.KitArService;
import br.com.frigelar.entrypoint.api.v1.converter.KitArRequestDTOMapper;
import br.com.frigelar.entrypoint.api.v1.dto.KitArDTO;
import br.com.frigelar.entrypoint.api.v1.dto.KitArRequestDTO;
import br.com.frigelar.entrypoint.api.v1.dto.KitArtResponseDTO;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.ext.web.RoutingContext;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;
import org.jboss.resteasy.reactive.RestPath;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@ApplicationScoped
@SecurityRequirement(name = "Keycloak")
@RequiredArgsConstructor
@Path("/v1/kit-ar")
public class KitArIntegrationResource {
    private final KitArService service;
    private final KitArRequestDTOMapper mapper;

    @POST
    public Uni<KitArtResponseDTO> save(KitArRequestDTO request, RoutingContext rc) {
        return Multi.createFrom()
                .iterable(request.getKitArDTOList())
                .map(mapper::toDomain)
                .flatMap(kitAr -> service.save(kitAr).toMulti())
                .map(mapper::toDTO)
                .collect()
                .asList()
                .map(kitArDTOList -> KitArtResponseDTO.builder().itemDTOList(kitArDTOList).build());
    }

    @PUT
    public Uni<KitArtResponseDTO> update(KitArRequestDTO request, RoutingContext rc) {
        return Multi.createFrom()
                .iterable(request.getKitArDTOList())
                .map(mapper::toDomain)
                .flatMap(kitAr -> service.update(kitAr).toMulti())
                .map(mapper::toDTO)
                .collect()
                .asList()
                .map(kitArDTOList -> KitArtResponseDTO.builder().itemDTOList(kitArDTOList).build());
    }

    @GET
    @Path("/{id}")
    public Uni<KitArDTO> getById(@RestPath String id) {
        return service.byID(id).map(mapper::toDTO);
    }
}
