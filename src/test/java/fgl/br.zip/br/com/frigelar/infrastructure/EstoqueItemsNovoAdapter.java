package br.com.frigelar.infrastructure;

import br.com.frigelar.domain.model.EstoqueItemsNovo;
import br.com.frigelar.domain.service.EstoqueItemsNovoPort;
import br.com.frigelar.infrastructure.converter.EstoqueItemsNovoMapper;
import br.com.frigelar.infrastructure.entity.EstoqueItemsNovoEntity;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;

import javax.enterprise.context.ApplicationScoped;
import java.time.Duration;

@ApplicationScoped
@RequiredArgsConstructor
public class EstoqueItemsNovoAdapter implements EstoqueItemsNovoPort {
    private final EstoqueItemsNovoMapper mapper;

    @Override
    public Uni<EstoqueItemsNovo> save(EstoqueItemsNovo estoqueItemsNovo) {
        return mapper.domainToEntity(estoqueItemsNovo)
                .persistOrUpdate()
                .map(entity -> mapper.entityToDomain((EstoqueItemsNovoEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }

    @Override
    public Uni<EstoqueItemsNovo> update(EstoqueItemsNovo estoqueItemsNovo) {
        return mapper.domainToEntity(estoqueItemsNovo)
                .update()
                .map(entity -> mapper.entityToDomain((EstoqueItemsNovoEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }

    @Override
    public Uni<EstoqueItemsNovo> byId(String id) {
        return EstoqueItemsNovoEntity.findById(id).map(entity -> mapper.entityToDomain((EstoqueItemsNovoEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }
}
