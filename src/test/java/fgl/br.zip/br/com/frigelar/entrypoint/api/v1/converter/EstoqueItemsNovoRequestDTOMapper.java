package br.com.frigelar.entrypoint.api.v1.converter;

import br.com.frigelar.domain.model.EstoqueItemsNovo;
import br.com.frigelar.entrypoint.api.v1.dto.EstoqueItemsNovoDTO;
import org.mapstruct.Mapper;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "cdi",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface EstoqueItemsNovoRequestDTOMapper {

    EstoqueItemsNovo toDomain(EstoqueItemsNovoDTO dto);

    EstoqueItemsNovoDTO toDTO(EstoqueItemsNovo item);

}
