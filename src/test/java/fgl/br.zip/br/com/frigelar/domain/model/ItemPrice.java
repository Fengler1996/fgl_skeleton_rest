package br.com.frigelar.domain.model;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ItemPrice {

    private String id;
    private String description;
    private String fiscalEstablishmentId;
    private Double fromPrice;
    private Double price;
}
