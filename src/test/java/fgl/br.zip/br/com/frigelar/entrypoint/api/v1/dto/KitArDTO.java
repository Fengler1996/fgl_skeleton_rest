package br.com.frigelar.entrypoint.api.v1.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(name = "KitArRequest", description = "Objeto de request")
@Getter
@Setter
@AllArgsConstructor
public class KitArDTO {


    @Schema(description = "id")
    @JsonProperty("id")
    private Long idNumericKitAr;

    @Schema(description = "kitId")
    @JsonProperty("kitId")
    private String kitId;

    @Schema(description = "bloqueadoLoja")
    private String bloqueadoLoja;

    @Schema(description = "bloqueadoFinal")
    private String bloqueadoFinal;

    @Schema(description = "btu")
    private String btu;

    @Schema(description = "fabricante")
    private String fabricante;

    @Schema(description = "ecAplicacaoPeca")
    @JsonProperty("ec_AplicacaoPeca")
    private String ecAplicacaoPeca;

    @Schema(description = "destaque")
    private String destaque;

    @Schema(description = "fglDepartamentoComercial")
    @JsonProperty("fgl_DepartamentoComercial")
    private String fglDepartamentoComercial;

    @Schema(description = "ecMarca")
    @JsonProperty("ec_Marca")
    private String ecMarca;

    @Schema(description = "ecRefMarca")
    @JsonProperty("ec_RefMarca")
    private String ecRefMarca;

    @Schema(description = "fglECDescritivo")
    @JsonProperty("fgl_EC_Descritivo")
    private String fglECDescritivo;

    @Schema(description = "fglReferenciaFor")
    @JsonProperty("fgl_ReferenciaFor")
    private String fglReferenciaFor;

    @Schema(description = "fglECLiberado")
    @JsonProperty("fgl_EC_Liberado")
    private String fglECLiberado;

    @Schema(description = "ecVoltagem")
    @JsonProperty("ec_Voltagem")
    private String ecVoltagem;

    @Schema(description = "grossDepth")
    private String grossDepth;

    @Schema(description = "createdDateTime")
    private String createdDateTime;

    @Schema(description = "fglReferencia")
    @JsonProperty("fgl_Referencia")
    private String fglReferencia;

    @Schema(description = "categoryIdSite")
    private Long categoryIdSite;

    @Schema(description = "ecSubCategoria")
    @JsonProperty("ec_SubCategoria")
    private String ecSubCategoria;

    @Schema(description = "ecFabricante")
    @JsonProperty("ec_Fabricante")
    private String ecFabricante;

    @Schema(description = "fglFotoUniversal")
    @JsonProperty("fgl_FotoUniversal")
    private String fglFotoUniversal;

    @Schema(description = "grossWidth")
    private Double grossWidth;

    @Schema(description = "idPecas")
    private Long idPecas;

    @Schema(description = "bloqueadoParceiro")
    private String bloqueadoParceiro;

    @Schema(description = "fglSuperfamilia")
    @JsonProperty("fgl_Superfamilia")
    private String fglSuperfamilia;

    @Schema(description = "grossHeight")
    private Double grossHeight;

    @Schema(description = "installments")
    private Double installments;

    @Schema(description = "integracaoPreco")
    private String integracaoPreco;

    @Schema(description = "integrado")
    private String integrado;

    @Schema(description = "ecCategoria")
    @JsonProperty("ec_Categoria")
    private String ecCategoria;

    @Schema(description = "combo")
    private String combo;

    @Schema(description = "precoTabela")
    private Double precoTabela;

    @Schema(description = "url")
    private String url;

    @Schema(description = "validade")
    private String validade;

    @Schema(description = "validade")
    private String name;

    @Schema(description = "maximumSaleQuantity")
    private Double maximumSaleQuantity;

    @Schema(description = "modifiedDateTime")
    private String modifiedDateTime;

    @Schema(description = "segmentId")
    private String segmentId;

    @Schema(description = "voltagem")
    private String voltagem;

    @Schema(description = "modifiedBy")
    private String modifiedBy;

    @Schema(description = "netWeight")
    private Double netWeight;

    @Schema(description = "priceId")
    private Long priceId;

    @Schema(description = "primaryVendorId")
    private String primaryVendorId;

    @Schema(description = "ordemFinal")
    private Long ordemFinal;

    @Schema(description = "tipo")
    private String tipo;

    @Schema(description = "kitType")
    private String kitType;

    @Schema(description = "productId")
    private Long productId;

    @Schema(description = "ordemLoja")
    private Long ordemLoja;

    @Schema(description = "ordemParceiro")
    private Long ordemParceiro;

    @Schema(description = "logoFabricante")
    private String logoFabricante;

    @Schema(description = "skuId")
    private Long skuId;
}
