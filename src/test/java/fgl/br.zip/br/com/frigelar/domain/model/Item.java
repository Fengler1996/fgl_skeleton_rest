package br.com.frigelar.domain.model;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class Item {

    private String id;
    private Long idSite;
    private String logoFabricante;
    private String bloqueadoFinal;
    private String bloqueadoParceiro;
    private String ecFabricante;
    private String ecMarca;
    private String fglReferencia;
    private String fglSubstituto;
    private String bloqueadoLoja;
    private String fglECDescritivo;
    private String fglReferenciaFor;
    private String fglSuperfamilia;
    private String bloqueadoInstalador;
    private String fglFamiliaItem;
    private Long categoryIdSite;
    private Long fglTempoGarantia;
    private Double grossHeight;
    private String homeFinal;
    private String ecVoltagem;
    private String fglFotoUniversal;
    private String homeInstalador;
    private String homeLoja;
    private String homeParceiro;
    private Double installments;
    private String fglLinhaProduto;
    private Double grossDepth;
    private Double grossWidth;
    private Double maximumSaleQuantity;
    private Long ordemInstalador;
    private String primaryVendorId;
    private String unEst;
    private Long ordemFinal;
    private String unCom;
    private String url;
    private Double netWeight;
    private Long ordemLoja;
    private String name;
    private Long ordemParceiro;
    private String unVen;
    private String pnvs;
    private String kitId;
}
