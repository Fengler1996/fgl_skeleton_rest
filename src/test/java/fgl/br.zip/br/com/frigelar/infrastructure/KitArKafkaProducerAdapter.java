package br.com.frigelar.infrastructure;

import br.com.frigelar.domain.model.KitAr;
import br.com.frigelar.domain.service.KitArProducerPort;
import br.com.frigelar.infrastructure.kafka.dto.OutTopicKafkaDTO;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.reactive.messaging.Channel;
import org.eclipse.microprofile.reactive.messaging.Emitter;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@RequiredArgsConstructor
public class KitArKafkaProducerAdapter implements KitArProducerPort {

    @Channel("petra2-product-kitAr-create-out")
    Emitter<OutTopicKafkaDTO> messageRequestEmitterCreate;

    @Channel("petra2-product-kitAr-update-out")
    Emitter<OutTopicKafkaDTO> messageRequestEmitterUpdate;

    @Override
    public Uni<KitAr> sendCreate(KitAr kitAr) {
        return Uni.createFrom()
                .completionStage(messageRequestEmitterCreate.send(OutTopicKafkaDTO.builder().id(kitAr.getKitId()).build()))
                .replaceWith(kitAr);
    }

    @Override
    public Uni<KitAr> sendUpdate(KitAr kitAr) {
        return Uni.createFrom()
                .completionStage(messageRequestEmitterUpdate.send(OutTopicKafkaDTO.builder().id(kitAr.getKitId()).build()))
                .replaceWith(kitAr);
    }
}
