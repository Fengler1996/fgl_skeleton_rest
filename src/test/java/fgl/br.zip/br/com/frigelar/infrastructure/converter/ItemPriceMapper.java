package br.com.frigelar.infrastructure.converter;

import br.com.frigelar.domain.model.ItemPrice;
import br.com.frigelar.infrastructure.entity.ItemPriceEntity;
import org.mapstruct.Mapper;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "cdi",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ItemPriceMapper {

    ItemPriceEntity domainToEntity(ItemPrice itemPrice);

    ItemPrice entityToDomain(ItemPriceEntity itemPriceEntity);
}
