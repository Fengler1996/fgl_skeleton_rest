package br.com.frigelar.infrastructure.kafka.converter;

import br.com.frigelar.domain.model.Item;
import br.com.frigelar.entrypoint.api.v1.dto.ItemDTO;
import org.mapstruct.Mapper;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "cdi",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ItemDTOMapper {
    ItemDTO domainToEntity(Item item);
}
