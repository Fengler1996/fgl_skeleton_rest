package br.com.frigelar.entrypoint.api.v1.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import javax.validation.constraints.NotBlank;

@Schema(name = "ItemDTO")
@Getter
@Setter
public class ItemDTO {

    @Schema(description = "itemId")
    @NotBlank(message = "{event.required}")
    @JsonProperty("itemId")
    private String id;

    @Schema(description = "idSite")
    private Long idSite;

    @Schema(description = "logoFabricante")
    private String logoFabricante;

    @Schema(description = "bloqueadoFinal")
    private String bloqueadoFinal;

    @Schema(description = "bloqueadoParceiro")
    private String bloqueadoParceiro;

    @JsonProperty("ec_Fabricante")
    @Schema(description = "ecFabricante")
    private String ecFabricante;

    @Schema(description = "ecMarca")
    @JsonProperty("ec_Marca")
    private String ecMarca;

    @Schema(description = "fglReferencia")
    @JsonProperty("fgl_Referencia")
    private String fglReferencia;

    @Schema(description = "fglSubstituto")
    @JsonProperty("fgl_Substituto")
    private String fglSubstituto;

    @Schema(description = "bloqueadoLoja")
    private String bloqueadoLoja;

    @Schema(description = "fglECDescritivo")
    @JsonProperty("fgl_EC_Descritivo")
    private String fglECDescritivo;

    @Schema(description = "fglReferenciaFor")
    @JsonProperty("fgl_ReferenciaFor")
    private String fglReferenciaFor;

    @Schema(description = "fglSuperfamilia")
    @JsonProperty("fgl_Superfamilia")
    private String fglSuperfamilia;

    @Schema(description = "bloqueadoInstalador")
    private String bloqueadoInstalador;

    @Schema(description = "fglFamiliaItem")
    @JsonProperty("fgl_FamiliaItem")
    private String fglFamiliaItem;

    @Schema(description = "categoryIdSite")
    private Long categoryIdSite;

    @Schema(description = "fglTempoGarantia")
    @JsonProperty("fgl_TempoGarantia")
    private Long fglTempoGarantia;

    @Schema(description = "grossHeight")
    private Double grossHeight;

    @Schema(description = "homeFinal")
    private String homeFinal;

    @Schema(description = "ecVoltagem")
    @JsonProperty("ec_Voltagem")
    private String ecVoltagem;

    @Schema(description = "fglFotoUniversal")
    @JsonProperty("fgl_FotoUniversal")
    private String fglFotoUniversal;

    @Schema(description = "homeInstalador")
    private String homeInstalador;

    @Schema(description = "homeLoja")
    private String homeLoja;

    @Schema(description = "homeParceiro")
    private String homeParceiro;

    @Schema(description = "installments")
    private Double installments;

    @Schema(description = "fglLinhaProduto")
    @JsonProperty("fgl_LinhaProduto")
    private String fglLinhaProduto;

    @Schema(description = "grossDepth")
    private Double grossDepth;

    @Schema(description = "grossWidth")
    private Double grossWidth;

    @Schema(description = "maximumSaleQuantity")
    private Double maximumSaleQuantity;

    @Schema(description = "ordemInstalador")
    private Long ordemInstalador;

    @Schema(description = "primaryVendorId")
    private String primaryVendorId;

    @Schema(description = "unEst")
    private String unEst;

    @Schema(description = "ordemFinal")
    private Long ordemFinal;

    @Schema(description = "unCom")
    private String unCom;

    @Schema(description = "url")
    private String url;

    @Schema(description = "netWeight")
    private Double netWeight;

    @Schema(description = "ordemLoja")
    private Long ordemLoja;

    @Schema(description = "name")
    private String name;

    @Schema(description = "ordemParceiro")
    private Long ordemParceiro;

    @Schema(description = "unVen")
    private String unVen;

    @Schema(description = "pnvs")
    private String pnvs;

    @Schema(description = "kitId")
    private String kitId;

}
