package br.com.frigelar.entrypoint.api.v1.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.util.List;

@Schema(name = "ItemPriceRequestDTO", description = "Objeto de request")
@Getter
@Setter
public class ItemPriceRequestDTO {

    @JsonProperty("ItemPrice")
    private List<ItemPriceDTO> itemPriceDTOList;
}
