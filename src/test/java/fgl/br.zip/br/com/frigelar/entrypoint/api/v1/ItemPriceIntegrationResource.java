package br.com.frigelar.entrypoint.api.v1;

import br.com.frigelar.domain.service.ItemPriceService;
import br.com.frigelar.entrypoint.api.v1.converter.ItemPriceRequestDTOMapper;
import br.com.frigelar.entrypoint.api.v1.dto.ItemPriceDTO;
import br.com.frigelar.entrypoint.api.v1.dto.ItemPriceRequestDTO;
import br.com.frigelar.entrypoint.api.v1.dto.ItemPriceResponseDTO;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.ext.web.RoutingContext;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;
import org.jboss.resteasy.reactive.RestPath;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@ApplicationScoped
@SecurityRequirement(name = "Keycloak")
@RequiredArgsConstructor
@Path("/v1/item-price")
public class ItemPriceIntegrationResource {
    private final ItemPriceService service;
    private final ItemPriceRequestDTOMapper mapper;

    @POST
    public Uni<ItemPriceResponseDTO> save(ItemPriceRequestDTO request, RoutingContext rc) {
        return Multi.createFrom()
                .iterable(request.getItemPriceDTOList())
                .map(mapper::toDomain)
                .flatMap(itemPrice -> service.save(itemPrice).toMulti())
                .map(mapper::toDTO)
                .collect()
                .asList()
                .map(ItemPriceResponseDTO::new);
    }

    @PUT
    public Uni<ItemPriceResponseDTO> update(ItemPriceRequestDTO request, RoutingContext rc) {
        return Multi.createFrom()
                .iterable(request.getItemPriceDTOList())
                .map(mapper::toDomain)
                .flatMap(item -> service.update(item).toMulti())
                .map(mapper::toDTO)
                .collect()
                .asList()
                .map(ItemPriceResponseDTO::new);
    }

    @GET
    @Path("/{id}")
    public Uni<ItemPriceDTO> getById(@RestPath String id) {
        return service.byID(id).map(mapper::toDTO);
    }
}
