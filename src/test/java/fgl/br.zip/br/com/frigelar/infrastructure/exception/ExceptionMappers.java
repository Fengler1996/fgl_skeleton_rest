package br.com.frigelar.infrastructure.exception;

import org.jboss.resteasy.reactive.RestResponse;
import org.jboss.resteasy.reactive.server.ServerExceptionMapper;

import java.time.ZonedDateTime;

/**
 * Classe responsável por interceptar as exceptions lançadas e tratar os retornos
 */
public class ExceptionMappers {
    @ServerExceptionMapper
    public RestResponse<ErrorDTO> mapExceptionBusinessException(BusinessException exception) {
        RestResponse.ResponseBuilder<ErrorDTO> builder = RestResponse.ResponseBuilder.create(422);
        return builder
                .entity(ErrorDTO.builder()
                        .withCode(exception.getCode())
                        .withError("Unprocessable Entity")
                        .withStatus(422)
                        .withMessage(exception.getMessage())
                        .withTimestamp(ZonedDateTime.now())
                        .build()).build();
    }

    @ServerExceptionMapper
    public RestResponse<ErrorDTO> mapExceptionFrigelarHttpException(FrigelarHttpException exception) {
        RestResponse.ResponseBuilder<ErrorDTO> builder = RestResponse.ResponseBuilder.create(exception.getCode());
        return builder
                .entity(ErrorDTO.builder()
                        .withStatus(exception.getCode())
                        .withMessage(exception.getMessage())
                        .withTimestamp(ZonedDateTime.now())
                        .build()).build();
    }
}
