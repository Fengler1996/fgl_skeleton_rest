package br.com.frigelar.domain.model;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class EstoqueItemsNovo {

    private String id;
    private Long productId;
    private Double counterSaleQuantity;
    private Double gondolaQuantity;
    private Double minSaleQuantity;
    private Double quantity;
    private Double reservedQuantity;
    private Long branchId;
    private Double quarentineQuantity;
    private Double saleQuantityMultiplier;
    private Double showroomQuantity;
    private Double transitQuantity;
    private Double storeQuantity;
    private Double webFglQuantity;
    private Double wareHouseQuantity;
    private Double webMktpQuantity;
    private Double supplierQuantity;

}
