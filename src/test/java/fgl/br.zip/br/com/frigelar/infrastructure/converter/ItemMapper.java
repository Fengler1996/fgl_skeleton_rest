package br.com.frigelar.infrastructure.converter;

import br.com.frigelar.domain.model.Item;
import br.com.frigelar.infrastructure.entity.ItemEntity;
import org.mapstruct.Mapper;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;


@Mapper(componentModel = "cdi",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ItemMapper {
    ItemEntity domainToEntity(Item item);

    Item entityToDomain(ItemEntity itemEntity);
}
