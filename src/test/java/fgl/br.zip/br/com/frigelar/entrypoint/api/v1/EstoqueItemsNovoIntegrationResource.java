package br.com.frigelar.entrypoint.api.v1;

import br.com.frigelar.domain.service.EstoqueItemsNovoService;
import br.com.frigelar.entrypoint.api.v1.converter.EstoqueItemsNovoRequestDTOMapper;
import br.com.frigelar.entrypoint.api.v1.dto.EstoqueItemsNovoDTO;
import br.com.frigelar.entrypoint.api.v1.dto.EstoqueItemsNovoRequestDTO;
import br.com.frigelar.entrypoint.api.v1.dto.EstoqueItemsNovoResponseDTO;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.ext.web.RoutingContext;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;
import org.jboss.resteasy.reactive.RestPath;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@ApplicationScoped
@SecurityRequirement(name = "Keycloak")
@RequiredArgsConstructor
@Path("/v1/estoque-item")
public class EstoqueItemsNovoIntegrationResource {
    private final EstoqueItemsNovoService service;
    private final EstoqueItemsNovoRequestDTOMapper mapper;

    @POST
    public Uni<EstoqueItemsNovoResponseDTO> save(EstoqueItemsNovoRequestDTO request, RoutingContext rc) {
        return Multi.createFrom()
                .iterable(request.getEstoqueItemsNovoDTOList())
                .map(mapper::toDomain)
                .flatMap(estoqueItemsNovo -> service.save(estoqueItemsNovo).toMulti())
                .map(mapper::toDTO)
                .collect()
                .asList()
                .map(EstoqueItemsNovoResponseDTO::new);
    }

    @PUT
    public Uni<EstoqueItemsNovoResponseDTO> update(EstoqueItemsNovoRequestDTO request, RoutingContext rc) {
        return Multi.createFrom()
                .iterable(request.getEstoqueItemsNovoDTOList())
                .map(mapper::toDomain)
                .flatMap(item -> service.update(item).toMulti())
                .map(mapper::toDTO)
                .collect()
                .asList()
                .map(EstoqueItemsNovoResponseDTO::new);
    }


    @GET
    @Path("/{id}")
    public Uni<EstoqueItemsNovoDTO> getById(@RestPath String id) {
        return service.byID(id).map(mapper::toDTO);
    }
}
