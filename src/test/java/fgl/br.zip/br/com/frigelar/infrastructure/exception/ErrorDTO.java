package br.com.frigelar.infrastructure.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.time.ZonedDateTime;
import java.util.List;

@RegisterForReflection
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "Error", description = "Classe de erros retornados pela API")
public class ErrorDTO {
    private final String code;
    private final String error;
    private final Integer status;
    private final String message;
    private final ZonedDateTime timestamp;
    private final List<ErrorDetailDTO> details;

    private ErrorDTO(Builder builder) {
        this.code = builder.code;
        this.error = builder.error;
        this.status = builder.status;
        this.message = builder.message;
        this.timestamp = builder.timestamp;
        this.details = builder.details;
    }

    public String getCode() {
        return code;
    }

    public String getError() {
        return error;
    }

    public Integer getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public ZonedDateTime getTimestamp() {
        return timestamp;
    }

    public List<ErrorDetailDTO> getDetails() {
        return details;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static Builder builderFrom(ErrorDTO errorDTO) {
        return new Builder(errorDTO);
    }

    public static final class Builder {
        private String code;
        private String error;
        private Integer status;
        private String message;
        private ZonedDateTime timestamp;
        private List<ErrorDetailDTO> details;

        private Builder() {
        }

        private Builder(ErrorDTO errorDTO) {
            this.code = errorDTO.code;
            this.error = errorDTO.error;
            this.status = errorDTO.status;
            this.message = errorDTO.message;
            this.timestamp = errorDTO.timestamp;
            this.details = errorDTO.details;
        }

        public Builder withCode(String code) {
            this.code = code;
            return this;
        }

        public Builder withError(String error) {
            this.error = error;
            return this;
        }

        public Builder withStatus(Integer status) {
            this.status = status;
            return this;
        }

        public Builder withMessage(String message) {
            this.message = message;
            return this;
        }

        public Builder withTimestamp(ZonedDateTime timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public Builder withDetails(List<ErrorDetailDTO> details) {
            this.details = details;
            return this;
        }

        public ErrorDTO build() {
            return new ErrorDTO(this);
        }
    }
}
