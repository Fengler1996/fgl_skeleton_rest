package br.com.frigelar.infrastructure;

import br.com.frigelar.domain.model.KitAr;
import br.com.frigelar.domain.service.KitArPort;
import br.com.frigelar.infrastructure.converter.KitArMapper;
import br.com.frigelar.infrastructure.entity.KitArEntity;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;

import javax.enterprise.context.ApplicationScoped;
import java.time.Duration;

@ApplicationScoped
@RequiredArgsConstructor
public class KitArAdapter implements KitArPort {
    private final KitArMapper mapper;

    @Override
    public Uni<KitAr> save(KitAr kitAr) {
        return mapper.domainToEntity(kitAr)
                .persistOrUpdate()
                .map(entity -> mapper.entityToDomain((KitArEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);

    }

    @Override
    public Uni<KitAr> update(KitAr kitAr) {
        return mapper.domainToEntity(kitAr)
                .update()
                .map(entity -> mapper.entityToDomain((KitArEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }

    @Override
    public Uni<KitAr> byId(String id) {
        return KitArEntity.findById(id).map(entity -> mapper.entityToDomain((KitArEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }
}
