package br.com.frigelar.infrastructure;

import br.com.frigelar.domain.model.Item;
import br.com.frigelar.domain.service.ItemPort;
import br.com.frigelar.infrastructure.converter.ItemMapper;
import br.com.frigelar.infrastructure.entity.ItemEntity;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;

import javax.enterprise.context.ApplicationScoped;
import java.time.Duration;

@ApplicationScoped
@RequiredArgsConstructor
public class ItemAdapter implements ItemPort {
    private final ItemMapper mapper;

    @Override
    public Uni<Item> save(Item item) {
        return mapper.domainToEntity(item)
                .persistOrUpdate()
                .map(entity -> mapper.entityToDomain((ItemEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }

    @Override
    public Uni<Item> update(Item item) {
        return mapper.domainToEntity(item)
                .update()
                .map(entity -> mapper.entityToDomain((ItemEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }

    @Override
    public Uni<Item> byId(String id) {
        return ItemEntity.findById(id).map(entity -> {
            return mapper.entityToDomain((ItemEntity) entity);
                }).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }
}
