package br.com.frigelar.infrastructure.entity;

import io.quarkus.mongodb.panache.common.MongoEntity;
import io.quarkus.mongodb.panache.reactive.ReactivePanacheMongoEntity;
import lombok.Getter;
import lombok.Setter;

@MongoEntity(collection = "mdm_ms_estoque_item")
@Getter
@Setter
public class EstoqueItemsNovoEntity extends ReactivePanacheMongoEntity {

    private String id;
    private Long productId;
    private Double counterSaleQuantity;
    private Double gondolaQuantity;
    private Double minSaleQuantity;
    private Double quantity;
    private Double reservedQuantity;
    private Long branchId;
    private Double quarentineQuantity;
    private Double saleQuantityMultiplier;
    private Double showroomQuantity;
    private Double transitQuantity;
    private Double storeQuantity;
    private Double webFglQuantity;
    private Double wareHouseQuantity;
    private Double webMktpQuantity;
    private Double supplierQuantity;
}
