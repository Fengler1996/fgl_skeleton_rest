package br.com.frigelar.infrastructure.kafka.dto;

import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Getter;
import lombok.Setter;

@RegisterForReflection
@Getter
@Setter
public class ItemPriceDTO {

    private String id;
    private String description;
    private String fiscalEstablishmentId;
    private Double fromPrice;
    private Double price;
}
