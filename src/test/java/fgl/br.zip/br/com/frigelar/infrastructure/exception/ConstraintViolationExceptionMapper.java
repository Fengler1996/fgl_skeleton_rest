package br.com.frigelar.infrastructure.exception;

import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.time.ZonedDateTime;
import java.util.List;

@Provider
public class ConstraintViolationExceptionMapper implements ExceptionMapper<ConstraintViolationException> {
    private static final String GENERIC_VALIDATION_ERROR_MESSAGE = "Ocorreu um erro ao validar os dados da solicitação";
    private static final String GENERIC_VALIDATION_ERROR_CODE = "ERR-00001";

    @Override
    public Response toResponse(ConstraintViolationException e) {
        var status = Response.Status.BAD_REQUEST;
        return Response.status(status).entity(ErrorDTO.builder()
                .withCode(GENERIC_VALIDATION_ERROR_CODE)
                .withError(status.getReasonPhrase())
                .withStatus(status.getStatusCode())
                .withMessage(GENERIC_VALIDATION_ERROR_MESSAGE)
                .withTimestamp(ZonedDateTime.now())
                .withDetails(extractErrorDetails(e))
                .build()).build();
    }

    private List<ErrorDetailDTO> extractErrorDetails(ConstraintViolationException exception) {
        return exception.getConstraintViolations()
                .stream()
                .map(error -> ErrorDetailDTO.builder()
                        .withField(error.getPropertyPath().toString())
                        .withKey(error.getMessageTemplate())
                        .withMessage(error.getMessage())
                        .build())
                .toList();

    }
}
