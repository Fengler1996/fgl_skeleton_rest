package br.com.frigelar.infrastructure;

import br.com.frigelar.domain.model.ItemPrice;
import br.com.frigelar.domain.service.ItemPriceProducerPort;
import br.com.frigelar.infrastructure.kafka.dto.OutTopicKafkaDTO;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.reactive.messaging.Channel;
import org.eclipse.microprofile.reactive.messaging.Emitter;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@RequiredArgsConstructor
public class ItemPriceProducerAdapter implements ItemPriceProducerPort {
    @Channel("petra2-product-item-price-create-out")
    Emitter<OutTopicKafkaDTO> messageRequestEmitterCreate;

    @Channel("petra2-product-item-price-update-out")
    Emitter<OutTopicKafkaDTO> messageRequestEmitterUpdate;

    @Override
    public Uni<ItemPrice> sendCreate(ItemPrice itemPrice) {
        return Uni.createFrom()
                .completionStage(messageRequestEmitterCreate.send(OutTopicKafkaDTO.builder().id(itemPrice.getId()).build()))
                .replaceWith(itemPrice);
    }

    @Override
    public Uni<ItemPrice> sendUpdate(ItemPrice itemPrice) {
        return Uni.createFrom()
                .completionStage(messageRequestEmitterUpdate.send(OutTopicKafkaDTO.builder().id(itemPrice.getId()).build()))
                .replaceWith(itemPrice);
    }
}
