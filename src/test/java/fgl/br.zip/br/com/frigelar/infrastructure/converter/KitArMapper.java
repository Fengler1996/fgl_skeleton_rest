package br.com.frigelar.infrastructure.converter;

import br.com.frigelar.domain.model.KitAr;
import br.com.frigelar.infrastructure.entity.KitArEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;


@Mapper(componentModel = "cdi",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface KitArMapper {
    @Mapping(target = "id", source = "kitId")
    KitArEntity domainToEntity(KitAr kitAr);

    @Mapping(target = "kitId", source = "id")
    KitAr entityToDomain(KitArEntity itemEntity);
}
