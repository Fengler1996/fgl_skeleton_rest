package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.Item;
import io.smallrye.mutiny.Uni;

public interface ItemPort {
    Uni<Item> save(Item item);

    Uni<Item> update(Item item);

    Uni<Item> byId(String id);
}
