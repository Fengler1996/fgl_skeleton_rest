package br.com.frigelar.infrastructure.kafka.serializer;

import br.com.frigelar.infrastructure.kafka.dto.OutTopicKafkaDTO;
import io.quarkus.kafka.client.serialization.ObjectMapperSerializer;

/**
 * Register serializer for OutTopicKafkaDTO
 */
public class OutTopicKafkaSerializer extends ObjectMapperSerializer<OutTopicKafkaDTO> {
}
