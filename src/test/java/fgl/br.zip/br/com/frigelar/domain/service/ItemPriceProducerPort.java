package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.ItemPrice;
import io.smallrye.mutiny.Uni;

public interface ItemPriceProducerPort {

    Uni<ItemPrice> sendCreate(ItemPrice itemPrice);

    Uni<ItemPrice> sendUpdate(ItemPrice itemPrice);
}
