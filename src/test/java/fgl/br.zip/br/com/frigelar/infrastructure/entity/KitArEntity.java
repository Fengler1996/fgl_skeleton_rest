package br.com.frigelar.infrastructure.entity;

import io.quarkus.mongodb.panache.common.MongoEntity;
import io.quarkus.mongodb.panache.reactive.ReactivePanacheMongoEntity;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@MongoEntity(collection = "mdm_ms_kit_art")
@Getter
@Setter
public class KitArEntity extends ReactivePanacheMongoEntity {

    private String id;
    private Long idNumericKitAr;
    private String bloqueadoLoja;
    private String bloqueadoFinal;
    private String btu;
    private String fabricante;
    private String ecAplicacaoPeca;
    private String destaque;
    private String fglDepartamentoComercial;
    private String ecMarca;
    private String ecRefMarca;
    private String fglECDescritivo;
    private String fglReferenciaFor;
    private String fglECLiberado;
    private String ecVoltagem;
    private String grossDepth;
    private String createdDateTime;
    private String fglReferencia;
    private Long categoryIdSite;
    private String ecSubCategoria;
    private String ecFabricante;
    private String fglFotoUniversal;
    private Double grossWidth;
    private Long idPecas;
    private String bloqueadoParceiro;
    private String fglSuperfamilia;
    private Double grossHeight;
    private Double installments;
    private String integracaoPreco;
    private String integrado;
    private String ecCategoria;
    private String combo;
    private Double precoTabela;
    private String url;
    private String validade;
    private String name;
    private Double maximumSaleQuantity;
    private String modifiedDateTime;
    private String segmentId;
    private String voltagem;
    private String modifiedBy;
    private Double netWeight;
    private Long priceId;
    private String primaryVendorId;
    private Long ordemFinal;
    private String tipo;
    private String kitType;
    private Long productId;
    private Long ordemLoja;
    private Long ordemParceiro;
    private String logoFabricante;
    private Long skuId;
    private Set<ItemEntity> items;

}
