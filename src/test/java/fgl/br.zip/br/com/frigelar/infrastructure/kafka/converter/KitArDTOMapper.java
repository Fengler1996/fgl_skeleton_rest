package br.com.frigelar.infrastructure.kafka.converter;

import br.com.frigelar.domain.model.KitAr;
import br.com.frigelar.infrastructure.kafka.dto.KitArDTO;
import org.mapstruct.Mapper;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "cdi",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface KitArDTOMapper {
    KitArDTO domainToEntity(KitAr kitAr);
}
