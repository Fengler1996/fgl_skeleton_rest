package br.com.frigelar.infrastructure.kafka.dto;

import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Getter;
import lombok.Setter;

@RegisterForReflection
@Getter
@Setter
public class KitArDTO {

    private String bloqueadoLoja;
    private String bloqueadoFinal;
    private String btu;
    private String fabricante;
    private String ecAplicacaoPeca;
    private String destaque;
    private String fglDepartamentoComercial;
    private String ecMarca;
    private String ecRefMarca;
    private String fglECDescritivo;
    private String fglReferenciaFor;
    private String fglECLiberado;
    private String ecVoltagem;
    private String grossDepth;
    private String createdDateTime;
    private String fglReferencia;
    private Long categoryIdSite;
    private String ecSubCategoria;
    private String ecFabricante;
    private String fglFotoUniversal;
    private Double grossWidth;
    private Long idPecas;
    private String bloqueadoParceiro;
    private String fglSuperfamilia;
    private Double grossHeight;
    private Double installments;
    private String integracaoPreco;
    private String integrado;
    private Long idNumericKitAr;
    private String kitId;
    private String ecCategoria;
    private String combo;
    private Double precoTabela;
    private String url;
    private String validade;
    private String name;
    private Double maximumSaleQuantity;
    private String modifiedDateTime;
    private String segmentId;
    private String voltagem;
    private String modifiedBy;
    private Double netWeight;
    private Long priceId;
    private String primaryVendorId;
    private Long ordemFinal;
    private String tipo;
    private String kitType;
    private Long productId;
    private Long ordemLoja;
    private Long ordemParceiro;
    private String logoFabricante;
    private Long skuId;
}
