package br.com.frigelar.infrastructure.exception;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

@RegisterForReflection
@Schema(name = "ErrorDetail", description = "Classe de detalhamento de erros retornados pela API")
public class ErrorDetailDTO {
    private String field;
    private String key;
    private String message;

    private ErrorDetailDTO(Builder builder) {
        this.field = builder.field;
        this.key = builder.key;
        this.message = builder.message;
    }

    public String getField() {
        return field;
    }

    public String getKey() {
        return key;
    }

    public String getMessage() {
        return message;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static Builder builderFrom(ErrorDetailDTO errorDetailDTO) {
        return new Builder(errorDetailDTO);
    }

    public static final class Builder {
        private String field;
        private String key;
        private String message;

        private Builder() {
        }

        private Builder(ErrorDetailDTO errorDetailDTO) {
            this.field = errorDetailDTO.field;
            this.key = errorDetailDTO.key;
            this.message = errorDetailDTO.message;
        }

        public Builder withField(String field) {
            this.field = field;
            return this;
        }

        public Builder withKey(String key) {
            this.key = key;
            return this;
        }

        public Builder withMessage(String message) {
            this.message = message;
            return this;
        }

        public ErrorDetailDTO build() {
            return new ErrorDetailDTO(this);
        }
    }

}
