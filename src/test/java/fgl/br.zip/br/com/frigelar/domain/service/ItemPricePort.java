package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.ItemPrice;
import io.smallrye.mutiny.Uni;

public interface ItemPricePort {

    Uni<ItemPrice> save(ItemPrice itemPrice);

    Uni<ItemPrice> update(ItemPrice itemPrice);

    Uni<ItemPrice> byId(String id);

}
