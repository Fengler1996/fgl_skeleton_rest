package br.com.frigelar.entrypoint.api.v1;

import br.com.frigelar.domain.service.ItemService;
import br.com.frigelar.entrypoint.api.v1.converter.ItemRequestDTOMapper;
import br.com.frigelar.entrypoint.api.v1.dto.ItemDTO;
import br.com.frigelar.entrypoint.api.v1.dto.ItemRequestDTO;
import br.com.frigelar.entrypoint.api.v1.dto.ItemResponseDTO;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import io.vertx.ext.web.RoutingContext;
import lombok.RequiredArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;
import org.jboss.resteasy.reactive.RestPath;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@ApplicationScoped
@SecurityRequirement(name = "Keycloak")
@RequiredArgsConstructor
@Path("/v1/item")
public class ItemIntegrationResource {
    private final ItemService service;
    private final ItemRequestDTOMapper mapper;

    @POST
    public Uni<ItemResponseDTO> save(ItemRequestDTO request, RoutingContext rc) {
        Log.infof("Save Items");
        return Multi.createFrom()
                .iterable(request.getItemDTOList())
                .map(mapper::toDomain)
                .flatMap(item -> service.save(item).toMulti())
                .map(mapper::toDTO)
                .collect()
                .asList()
                .map(ItemResponseDTO::new);
    }

    @PUT
    public Uni<ItemResponseDTO> update(ItemRequestDTO request, RoutingContext rc) {
        return Multi.createFrom()
                .iterable(request.getItemDTOList())
                .map(mapper::toDomain)
                .flatMap(item -> service.update(item).toMulti())
                .map(mapper::toDTO)
                .collect()
                .asList()
                .map(itemDTOList -> ItemResponseDTO.builder().itemDTOList(itemDTOList).build());
    }

    @GET
    @Path("/{id}")
    public Uni<ItemDTO> getById(@RestPath String id) {
        return service.byID(id).map(mapper::toDTO);
    }

}
