package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.EstoqueItemsNovo;
import io.smallrye.mutiny.Uni;

public interface EstoqueItemsNovoPort {
    Uni<EstoqueItemsNovo> save(EstoqueItemsNovo estoqueItemsNovo);

    Uni<EstoqueItemsNovo> update(EstoqueItemsNovo estoqueItemsNovo);

    Uni<EstoqueItemsNovo> byId(String id);
}
