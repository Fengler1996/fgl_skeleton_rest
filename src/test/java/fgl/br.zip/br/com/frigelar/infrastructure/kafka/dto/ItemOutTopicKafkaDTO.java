package br.com.frigelar.infrastructure.kafka.dto;

import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@RegisterForReflection
public class ItemOutTopicKafkaDTO {

    private String id;
    private String idKitAr;

}
