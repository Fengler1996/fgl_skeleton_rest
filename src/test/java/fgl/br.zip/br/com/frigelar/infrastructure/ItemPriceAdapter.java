package br.com.frigelar.infrastructure;

import br.com.frigelar.domain.model.ItemPrice;
import br.com.frigelar.domain.service.ItemPricePort;
import br.com.frigelar.infrastructure.converter.ItemPriceMapper;
import br.com.frigelar.infrastructure.entity.ItemPriceEntity;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;

import javax.enterprise.context.ApplicationScoped;
import java.time.Duration;

@ApplicationScoped
@RequiredArgsConstructor
public class ItemPriceAdapter implements ItemPricePort {

    private final ItemPriceMapper mapper;

    @Override
    public Uni<ItemPrice> save(ItemPrice itemPrice) {
        return mapper.domainToEntity(itemPrice)
                .persistOrUpdate()
                .map(entity -> mapper.entityToDomain((ItemPriceEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }

    @Override
    public Uni<ItemPrice> update(ItemPrice item) {
        return mapper.domainToEntity(item)
                .update()
                .map(entity -> mapper.entityToDomain((ItemPriceEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }

    @Override
    public Uni<ItemPrice> byId(String id) {
        return ItemPriceEntity.findById(id).map(entity -> mapper.entityToDomain((ItemPriceEntity) entity)).onFailure().retry()
                .withBackOff(Duration.ofSeconds(1)).withJitter(0.2).atMost(3);
    }
}
