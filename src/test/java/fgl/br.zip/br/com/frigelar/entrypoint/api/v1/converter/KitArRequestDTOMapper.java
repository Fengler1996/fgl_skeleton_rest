package br.com.frigelar.entrypoint.api.v1.converter;

import br.com.frigelar.entrypoint.api.v1.dto.KitArDTO;
import br.com.frigelar.domain.model.KitAr;
import org.mapstruct.Mapper;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;


@Mapper(componentModel = "cdi",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface KitArRequestDTOMapper {
    KitAr toDomain(KitArDTO dto);

    KitArDTO toDTO(KitAr kitAr);
}
