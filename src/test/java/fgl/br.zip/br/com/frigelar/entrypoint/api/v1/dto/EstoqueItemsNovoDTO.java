package br.com.frigelar.entrypoint.api.v1.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import javax.validation.constraints.NotBlank;

@Schema(name = "EstoqueItemsNovoDTO")
@Getter
@Setter
public class EstoqueItemsNovoDTO {

    @Schema(description = "itemId")
    @NotBlank(message = "{event.required}")
    @JsonProperty("itemId")
    private String id;

    private Long productId;
    private Double counterSaleQuantity;
    private Double gondolaQuantity;
    private Double minSaleQuantity;
    private Double quantity;
    private Double reservedQuantity;
    private Long branchId;
    private Double quarentineQuantity;
    private Double saleQuantityMultiplier;
    private Double showroomQuantity;
    private Double transitQuantity;
    private Double storeQuantity;
    private Double webFglQuantity;
    private Double wareHouseQuantity;
    private Double webMktpQuantity;
    private Double supplierQuantity;
}
