package br.com.frigelar.infrastructure.kafka.dto;

import io.quarkus.runtime.annotations.RegisterForReflection;
import lombok.Getter;
import lombok.Setter;

@RegisterForReflection
@Getter
@Setter
public class EstoqueItemsNovoDTO {

    private String id;
    private Long productId;
    private Double counterSaleQuantity;
    private Double gondolaQuantity;
    private Double minSaleQuantity;
    private Double quantity;
    private Double reservedQuantity;
    private Long branchId;
    private Double quarentineQuantity;
    private Double saleQuantityMultiplier;
    private Double showroomQuantity;
    private Double transitQuantity;
    private Double storeQuantity;
    private Double webFglQuantity;
    private Double wareHouseQuantity;
    private Double webMktpQuantity;
    private Double supplierQuantity;
}
