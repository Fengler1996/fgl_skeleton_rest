package br.com.frigelar.infrastructure.converter;

import br.com.frigelar.domain.model.EstoqueItemsNovo;
import br.com.frigelar.infrastructure.entity.EstoqueItemsNovoEntity;
import org.mapstruct.Mapper;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "cdi",
        nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
        unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface EstoqueItemsNovoMapper {

    EstoqueItemsNovoEntity domainToEntity(EstoqueItemsNovo estoqueItemsNovo);

    EstoqueItemsNovo entityToDomain(EstoqueItemsNovoEntity estoqueItemsNovoEntity);
}
