package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.KitAr;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@RequiredArgsConstructor
public class KitArServiceImpl implements KitArService {

    private final KitArPort kitArPort;
    private final KitArProducerPort kitArProducerPort;


    @Override
    public Uni<KitAr> save(KitAr kitAr) {
        return kitArPort.save(kitAr).flatMap(e -> kitArProducerPort.sendCreate(kitAr));
    }

    @Override
    public Uni<KitAr> update(KitAr kitAr) {
        return kitArPort.update(kitAr).flatMap(e -> kitArProducerPort.sendUpdate(kitAr));
    }

    @Override
    public Uni<KitAr> byID(String id) {
        return kitArPort.byId(id);
    }

}
