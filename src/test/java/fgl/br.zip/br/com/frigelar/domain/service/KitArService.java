package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.KitAr;
import io.smallrye.mutiny.Uni;

public interface KitArService {

    Uni<KitAr> save(KitAr kitAr);

    Uni<KitAr> update(KitAr kitAr);

    Uni<KitAr> byID(String id);
}
