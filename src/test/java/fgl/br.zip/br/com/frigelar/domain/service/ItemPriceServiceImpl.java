package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.ItemPrice;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@RequiredArgsConstructor
public class ItemPriceServiceImpl implements ItemPriceService {
    private final ItemPricePort itemPricePort;
    private final ItemPriceProducerPort itemPriceProducerPort;

    @Override
    public Uni<ItemPrice> save(ItemPrice itemPrice) {
        return itemPricePort.save(itemPrice).flatMap(e -> itemPriceProducerPort.sendCreate(itemPrice));
    }

    @Override
    public Uni<ItemPrice> update(ItemPrice itemPrice) {
        return itemPricePort.update(itemPrice).flatMap(e -> itemPriceProducerPort.sendUpdate(itemPrice));
    }

    @Override
    public Uni<ItemPrice> byID(String id) {
        return itemPricePort.byId(id);
    }
}