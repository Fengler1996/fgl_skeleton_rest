package br.com.frigelar.infrastructure.kafka;

import br.com.frigelar.domain.service.ItemService;
import br.com.frigelar.domain.service.KitArService;
import br.com.frigelar.infrastructure.kafka.dto.ItemOutTopicKafkaDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.opentracing.Span;
import io.opentracing.SpanContext;
import io.opentracing.Tracer;
import io.opentracing.contrib.kafka.TracingKafkaUtils;
import io.opentracing.util.GlobalTracer;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import io.smallrye.reactive.messaging.kafka.api.IncomingKafkaRecordMetadata;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.eclipse.microprofile.reactive.messaging.Message;

import javax.enterprise.context.ApplicationScoped;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Objects;

@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class ItemConsumer {
    private final KitArService service;
    private final ItemService itemService;

    @Incoming("petra2-product-item-create-in")
    @Retry(delay = 10, maxRetries = 5, delayUnit = ChronoUnit.SECONDS)
    public Uni<Void> consume(Message<ItemOutTopicKafkaDTO> msg) throws JsonProcessingException {
        //Opentracing code keep context
        SpanContext spanContext = TracingKafkaUtils.extractSpanContext(msg.getMetadata(IncomingKafkaRecordMetadata.class).get().getHeaders(), GlobalTracer.get());
        Tracer.SpanBuilder spanBuilder = GlobalTracer.get().buildSpan("my span").addReference("child_of", spanContext);
        Span start = spanBuilder.start();
        GlobalTracer.get().activateSpan(start);

        log.info("Recebendo mensagem petra2-product-item-create-in ---> \n" + new ObjectMapper().writer().withDefaultPrettyPrinter().writeValueAsString(msg.getPayload()));
        var payload = msg.getPayload();
        if (Objects.nonNull(payload.getIdKitAr())) {
            return service.byID(payload.getIdKitAr()).onItem().ifNotNull()
                    .transformToUni(w -> itemService.byID(payload.getId())
                            .flatMap(t -> {
                                if (Objects.isNull(w.getItems())) {
                                    w.setItems(new HashSet<>());
                                }
                                w.validateNewItem(w.getItems(), t);
                                return service.save(w);
                            })
                    ).onItem()
                    .call(() -> {
                        start.finish();
                        return Uni.createFrom().completionStage(msg.ack());
                    })
                    .onFailure()
                    .call(t -> {
                        Log.error("Falha ao consumir petra2-product-item-create-in", t);
                        start.finish();
                        return Uni.createFrom().completionStage(msg.nack(t));
                    }).replaceWithVoid();
        }
        return Uni.createFrom().completionStage(msg.ack()).replaceWithVoid();
    }


}

