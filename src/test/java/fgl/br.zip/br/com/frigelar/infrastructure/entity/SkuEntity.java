package br.com.frigelar.infrastructure.entity;

import io.quarkus.mongodb.panache.common.MongoEntity;
import io.quarkus.mongodb.panache.reactive.ReactivePanacheMongoEntity;
import lombok.Getter;
import lombok.Setter;

@MongoEntity(collection = "mdm_ms_sku")
@Getter
@Setter
public class SkuEntity extends ReactivePanacheMongoEntity {
	
	private String name;
	private Boolean lockedShop;
	private Boolean lockedPartner;
	private Boolean finalLocked;
	private String btu;
	private Integer categoryIdSite;
	
	
}
