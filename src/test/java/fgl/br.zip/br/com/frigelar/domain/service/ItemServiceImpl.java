package br.com.frigelar.domain.service;

import br.com.frigelar.domain.model.Item;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import lombok.RequiredArgsConstructor;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@RequiredArgsConstructor
public class ItemServiceImpl implements ItemService {
    private final ItemPort itemPort;
    private final ItemProducerPort itemProducerPort;

    @Override
    public Uni<Item> save(Item item) {
        Log.infof("Save Item: %s", item.getId());
        return itemPort.save(item).flatMap(e -> itemProducerPort.sendCreate(item));
    }

    @Override
    public Uni<Item> update(Item item) {
        return itemPort.update(item).flatMap(e -> itemProducerPort.sendUpdate(item));
    }

    @Override
    public Uni<Item> byID(String id) {
        return itemPort.byId(id);
    }

}

