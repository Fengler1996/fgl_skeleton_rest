package br.com.frigelar.infrastructure.config;

import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.config.MeterFilter;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import javax.inject.Singleton;
import javax.ws.rs.Produces;
import java.util.Arrays;

@Singleton
public class MicometerConfiguration {
    @ConfigProperty(name = "quarkus.application.name")
    String application;

    /**
     * Define common tags that apply globally
     */
    @Produces
    @Singleton
    public MeterFilter configureAllRegistries() {
        return MeterFilter.commonTags(Arrays.asList(
                Tag.of("application", application)));
    }
}
